# Financial-Modelling-and-Analysis-of-Housing-Project-in-Gurgaon
Created a Financial Model usingExcelfor50 Flats, analyzedCost,Revenue, andFinflowsfor the projectand projected the feasibility of the project by estimating10years projection for all indicators
